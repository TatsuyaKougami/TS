Types for Google Cloud Bigquery v2 API
======================================

.. automodule:: google.cloud.bigquery.standard_sql
    :members:
    :undoc-members:
    :show-inheritance:

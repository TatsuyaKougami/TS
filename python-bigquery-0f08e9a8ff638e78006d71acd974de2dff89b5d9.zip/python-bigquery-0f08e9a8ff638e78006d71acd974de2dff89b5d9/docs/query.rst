Query Resource Classes
======================

.. automodule:: google.cloud.bigquery.query
    :members:

Common Job Resource Classes
===========================

.. automodule:: google.cloud.bigquery.job.base
    :members:

Client Library Design
=====================

Some features of this client library have complex requirements and/or
implementation. These documents describe the design decisions that contributued
to those features.

.. toctree::
  :maxdepth: 2

  query-retries
